Apache Avro Distribution 

Avro is a data serialization system.

This distribution contains the following files:

  - avro-src-x.y.z.tar.gz contains the full source for Avro, including
    all programming language implementations, documentation source, etc.

  - avro-doc-x.y.z.tar.gz contains Avro's pre-built documentation.

  - the c/, cpp/, java/, php/, py/, and ruby/ subdirectories contain
    pre-built, language-specific binaries, bundles, etc. as
    conveniences.
